/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventarioferreteria;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Mari
 */
public class Serializacion {

  String filename = "Inventario.txt";

  public void serializar(Inventario in) {
    try {
      FileOutputStream fo = new FileOutputStream(filename);
      ObjectOutputStream so = new ObjectOutputStream(fo);
      so.writeObject(in);
      so.flush();
    } catch (Exception e) {
      System.out.println(e);
      System.exit(1);
    }
  }

  public Inventario deserializar() {
    //ArrayList<Producto> list = new ArrayList();
    Inventario in = new Inventario();
    FileInputStream fi;
    try {
      fi = new FileInputStream(filename);
      ObjectInputStream si = new ObjectInputStream(fi);
      in = (Inventario) si.readObject();
    } catch (FileNotFoundException ex) {
      Logger.getLogger(Serializacion.class.getName()).log(Level.SEVERE, null, ex);
    } catch (IOException | ClassNotFoundException ex) {
      Logger.getLogger(Serializacion.class.getName()).log(Level.SEVERE, null, ex);
    }
    return in;
  }

}
