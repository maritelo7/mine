/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventarioferreteria;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 *
 * @author Mari
 */
public class Venta {

  Teclado t = new Teclado();
  ArrayList<String> listaV = new ArrayList<>();
  Inventario in = new Inventario();
  Producto prod = new Producto();
  int contador = 0;

  public void realizarVenta() throws IOException {
   
    File f = new File("Ventas.txt");
    listaV.add("Venta: " + contador);
    System.out.println("CUANDO TERMINÉ DE REGISTRAR LA VENTA PRESIONE ´X´ ");
    int paro = 0;
    int aux;
    double precio = 0.0;
    int cantidad = 0;
    boolean encontrado = false;
    double totalVenta = 0.0;
    do {
      System.out.println("Ingrese la clave del producto a vender");
      aux = t.leerEntero();
      for (int i = 0; i < in.lista.size(); i++) {
        prod = in.lista.get(i);
        if (aux == prod.getClave()) {
          precio = prod.getPrecioCompra();
          precio = (precio * .70) + precio;
          encontrado = true;
        }
      }
      if (encontrado == true) {
        System.out.println("Ingrese cantidad de artículos");
        cantidad = t.leerEntero();
        if (prod.getExistencia() >= cantidad) {
          prod.setExistencia(prod.getExistencia() - cantidad);        
        }else{
        encontrado =false;
        }       
      }else{
        System.out.println("No se encontró el producto");
      }
      if(encontrado == true){
      double totalArticulo = precio * cantidad;
      totalVenta = totalArticulo + totalVenta;
      listaV.add("Artículo: " + prod.getNombre() + "  Cantidad: " + cantidad + "  Precio unitario: " + precio + " Total: " + totalArticulo);
    }
    } while (!String.valueOf(paro).equals("X") || !String.valueOf(paro).equals("x"));
  if (encontrado == true){
  listaV.add("Total de la venta: " +  totalVenta);
  listaV.add("--------------------------------------------------------");
  }
   PrintWriter pw = new PrintWriter(f);
   pw.println(listaV);
   pw.close();
  }
  
  public void mostrarVentas() throws IOException {
    File f = new File("Ventas.txt");
    FileInputStream fis = new FileInputStream(f);
    InputStreamReader isr = new InputStreamReader(fis, "UTF8");
    BufferedReader br = new BufferedReader(isr);
    String linea = br.readLine();
    while (linea != null) {
      System.out.println(linea);
    }
    br.close();
    isr.close();
    fis.close();
  }
}
