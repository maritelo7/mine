/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventarioferreteria;

import java.io.*;
/**
 *
 * @author Mari
 * version 0.1
 */
public class Producto implements Serializable {

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public String getDescripcion() {
    return descripcion;
  }

  public void setDescripcion(String descripcion) {
    this.descripcion = descripcion;
  }

  public int getExistencia() {
    return existencia;
  }

  public void setExistencia(int existencia) {
    this.existencia = existencia;
  }

  public double getPrecioCompra() {
    return precioCompra;
  }

  public void setPrecioCompra(double precioCompra) {
    this.precioCompra = precioCompra;
  }

  public String getUnidadMedida() {
    return unidadMedida;
  }

  public void setUnidadMedida(String unidadMedida) {
    this.unidadMedida = unidadMedida;
  }
  
    public int getClave() {
    return clave;
  }

  public void setClave(int clave) {
    this.clave = clave;
  }
  
  private int clave;
  private String nombre;
  private String descripcion;
  private int existencia;
  private double precioCompra;
  private String unidadMedida;

  public Producto (){}
 
  public Producto(String nombre, String descripcion, int existencia, double precioCompra, String unidadMedida, int clave){
    this.clave = clave;
    this.nombre = nombre;
    this.descripcion = descripcion;
    this.existencia = existencia;
    this.precioCompra = precioCompra;
    this.unidadMedida = unidadMedida;
  }
  
  @Override
  public String toString() {
	return("Clave: " + clave + "\nName: " + nombre + "\n" + "Descripción: " + descripcion + "\n" + "Existencia: " + existencia  + " " + unidadMedida + "\n" + "Precio de compra: " + precioCompra + "\n");
    }

}
