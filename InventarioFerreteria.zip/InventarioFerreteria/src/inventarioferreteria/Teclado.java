/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventarioferreteria;

import java.util.Scanner;

/**
 * @author Maribel Tello Rodríguez
 * @version 0.1
 */
public class Teclado {
    private final Scanner sc;
     /**
     * Inicializa la clase Scanner con la entrada estándar que es la lectura desde el teclado
     */
    public Teclado(){
        sc = new Scanner(System.in);
    }
    /**
     * Este método lee un entero
     * @return Regresa un valor de tipo entero 
     */
    public int leerEntero(){
       return sc.nextInt();
    }
    /**
     * Este método lee un doble
     * @return Regresa un valor de tipo double
     */
    public double leerDouble(){
        return sc.nextDouble();
    }
    
    public String leerString(){
        return sc.next();
    }
    
}
