/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventarioferreteria;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author Mari
 */
public class Ferreteria {

  public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException {
    Teclado tec = new Teclado();
    Producto pro = new Producto();
    Inventario in = new Inventario();
    MensajesUsuario mu = new MensajesUsuario();
    Serializacion ser = new Serializacion();
    Venta v = new Venta();
    File f = new File("Inventario.txt");
    if (f.exists()) {
      in = ser.deserializar();
    } else {
      f.createNewFile();
    }

    int op = 0;

    do {
      mu.menu();
      try {
        op = mu.leerOpcion();
      } catch (NumberFormatException e) {
      }
      switch (op) {
        case 1:
          do {
            mu.menuCompra();
            try {
              op = mu.leerOpcion();
            } catch (NumberFormatException e) {
            }
            mu.realizarOpcion(op, tec, pro, in, ser);
          } while (op != 0);
          break;
        case 2:
          do {
            mu.menuVenta();
            try {
              op = mu.leerOpcion();
            } catch (NumberFormatException e) {
            }
           mu.escogerVentaCompra(op, v);
          } while (op != 0);
          break;
      }

    } while (op != 0);

  }

}
